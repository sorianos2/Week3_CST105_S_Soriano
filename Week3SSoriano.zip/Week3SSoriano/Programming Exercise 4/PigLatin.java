/** Program: Translate text file to Pig Latin.
 * Summary: Open text file and read contents of the file and translate it to Pig Latin.
 * Author: Samuel Soriano
 * Date: June 27, 2017
 */

import java.io.*;
import java.util.Scanner;

public class PigLatin {
    /* Main Method*/
      public static void main(String[] args) throws FileNotFoundException {
        // Create a Scanner for the file that's going to be read.
        Scanner input = new Scanner(new File("//Users//samsoriano//Desktop//piglatin.txt"));
        
        // Read the file
        while (input.hasNext()) {
            String word = input.next();
            System.out.println(word);
            Scanner words = new Scanner(word);
            
            // Translate words into Pig Latin
            while (words.hasNext()) {
                String pig = words.next();
                String pigLatin = pigLatinWord(pig);
                System.out.println(pigLatin.toUpperCase());
            }
            // Display the words in the file and the translated words
            System.out.printf("");
        }
    }

    /* Create Method for translating words to Pig Latin */
    public static String pigLatinWord(String s) {
        String pigWord;
        // If word starts with a vowel add "way" to the end of the word
        if (isVowel(s.charAt(0))) {
            pigWord = s + "way";
        }
        // If word starts with "th" or "TH" move to the end of the word and add "ay"
        else if (s.startsWith("th") || s.startsWith("Th")) {
            pigWord = s.substring(2) + s.substring(0,2) + "ay";
        } 
        // If word starts with a consonant move to the end of the word and add "ay"
        else {
            pigWord = s.substring(1,s.length()) + s.charAt(0) + "ay";
        }
        // return the Pig Latin word
        return pigWord;
    }

    /* Create method for isVowel */
    public static boolean isVowel(char c) {
        String vowels = "aeiouAEIOU";
        return (vowels.indexOf(c) >= 0);
    }
}
